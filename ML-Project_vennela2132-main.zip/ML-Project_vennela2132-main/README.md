# ML-Project_vennela2132
Prediction of possibility of rain occurring the next day in Australia. Achieved 84.9% accuracy using RandomForestClassifier.
